package com.galmaegi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PreprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
